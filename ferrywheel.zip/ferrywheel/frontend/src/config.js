export const baseURL = "";
export const adminBaseURL = "";
export const key = "";