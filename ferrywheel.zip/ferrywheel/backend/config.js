module.exports = {
  adminBaseURL: "",
  PORT: 5000,
  mongoDbConnectionString: "",
};
